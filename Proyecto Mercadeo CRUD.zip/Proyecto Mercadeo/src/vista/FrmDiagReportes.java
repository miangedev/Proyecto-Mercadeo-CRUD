package vista;

import java.awt.Frame;

public class FrmDiagReportes {

    public FrmDiagReportes(Frame frame, boolean b) {
        //TODO Auto-generated constructor stub
    }

    public void setLocationRelativeTo(Object object) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setLocationRelativeTo'");
    }

    public void setVisible(boolean b) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setVisible'");
    }

}
